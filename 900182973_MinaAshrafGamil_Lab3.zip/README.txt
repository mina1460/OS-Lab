the makefile works only in the same directory as the code. So place them in the same directory before running make command.

the new menuentry is written in the file called 40_custom and should be placed inside /etc/grub.d

the entry has the same name as the default debain configuration but with a "No KASLR" string attached to the name at the end

the only modification to the normal menuentry is the "nokaslr" added to the options of the boot cmd