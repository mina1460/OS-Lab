#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kernel.h>
#include <linux/stat.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("ElKing Mina Ashraf");

static int loop = 1;
static char* msg;

module_param(loop, int, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP);
MODULE_PARM_DESC(loop, "Number of iterations for the loop of printing the message");

module_param(msg, charp, 0000);
MODULE_PARM_DESC(msg, "The message to be printed inside the loop body");

static int __init init_hello(void)
{
	int i;
	for(i=0; i<loop; i++){
		printk(KERN_INFO "%s \n", msg);
	}
	/*
	printk(KERN_INFO "Hello world CSCE-3402 :) \n");
	*/

	return 0;
}

static void __exit cleanup_hello(void)
{
	printk(KERN_INFO "Bye Bye CSCE-3402 :) .\n");
}

module_init(init_hello);
module_exit(cleanup_hello);
