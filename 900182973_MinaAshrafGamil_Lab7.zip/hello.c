#include <linux/init.h>
#include <linux/string.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kernel.h>
#include <linux/stat.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/fcntl.h>
#include <linux/file.h>
#include <linux/unistd.h>
#include <linux/slab.h>
#include <linux/proc_fs.h>
#include <linux/cred.h>
#include <linux/kallsyms.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("ElKing Mina Ashraf");
bool found = false;
int fork_counter = 0;
static unsigned long *sys_call_table_m;

asmlinkage ssize_t (*old_fork)(unsigned long flags, void* stack, int *parent_tid, int *child_tid, unsigned long tls);


asmlinkage ssize_t my_fork(unsigned long flags, void *stack, int *parent_tid, int *child_tid, unsigned long tls){
	fork_counter++;
	long r;
	if (fork_counter%10 == 0)
		printk(KERN_INFO "Fork count: %d \n",fork_counter);
	
	r = (*old_fork)(flags, stack, parent_tid, child_tid, tls);
	return r;
}


inline void mywrite_cr0(unsigned long val)
{
    asm volatile("mov %0,%%cr0": "+r" (val), "+m" (__force_order));
}


static void enable_write_protection(void)
{
  unsigned long cr0 = read_cr0();
  set_bit(16, &cr0);
  mywrite_cr0(cr0);
}

static void disable_write_protection(void)
{
  unsigned long cr0 = read_cr0();
  clear_bit(16, &cr0);
  mywrite_cr0(cr0);
}


static int __init init_hello(void)
{
	sys_call_table_m = (void *)kallsyms_lookup_name("sys_call_table");
	printk(KERN_INFO "fork address from kallsyms is in lx: %lx \n", sys_call_table_m[__NR_clone]);

 	disable_write_protection();
    old_fork = ( void *)xchg(&sys_call_table_m[__NR_clone], my_fork);
    enable_write_protection();
	
	printk(KERN_INFO "the old fork address: %p \n", old_fork);
	printk(KERN_INFO "my fork address: %p \n", my_fork);
	printk(KERN_INFO "the exchanged address: %p \n",&sys_call_table_m[__NR_clone]);

	return 0;
}

static void __exit cleanup_hello(void)
{
    disable_write_protection();
    xchg(&sys_call_table_m[__NR_clone], old_fork);
    enable_write_protection();
    printk(KERN_INFO "Module removed \n");
}

module_init(init_hello);
module_exit(cleanup_hello);
