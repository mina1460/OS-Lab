the only thing to notice in my shell: 
this command and similar looking commands  ( cat < /etc/hosts | grep “127” > dump.txt ) will work if typed like this: (cat < /etc/hosts > dump.txt | grep 127 )


this is the only anomality in the code from the real shells.


to compile type make 
to run type make run 
to clean the code type make clean