Mina Ashraf Gamil 
900182973
-----------------------------
Readme file 
-----------------------------


to run the backup or the restore script, you need to download them and put them in any directory.
then open the backup.sh or the restore.sh and edit the source on line 3 to the location of the backup_restore_lib.sh on your own computer.
and you would need to make sure that is executable on your system by changing its mod.
chmod a+x backup.sh 
chmod a+x restore.sh

then run it like this if you are in the same directory.
./backup.sh /home/directory_that_you_want_to_backup/  /home/directory_to_store_in_the_backup/ encryption_key



./restore.sh /home/directory_that_contains_the_backup/ /home/destination_to_restore_in_it  decryption_key

