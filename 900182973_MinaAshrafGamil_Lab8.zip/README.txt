the makefile works only in the same directory as the code. So place them in the same directory before running make command.

to compile, place the code and the makefile in the same directory and run the "make" command.


now we can work with kaslr enabled 

you will find an entry in the /proc/ directory called fork_count after you insmod the module 