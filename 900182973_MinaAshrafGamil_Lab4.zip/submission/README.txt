the makefile works only in the same directory as the code. So place them in the same directory before running make command.

to compile, place the code and the makefile in the same directory and run the "make" command.

output is in two lines:
[ 5723.467531] full file content: Linux version 4.19.0-13-amd64 (debian-kernel@lists.debian.org) (gcc version 8.3.0 (Debian 8.3.0-6))  
[ 5723.467533] kernel version:4.19.0-13-amd64  
[ 5727.327562] Module removed 


the second line is the desired output (the kernel version)