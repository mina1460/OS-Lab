#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kernel.h>
#include <linux/stat.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/fcntl.h>
#include <linux/syscalls.h>
#include <linux/file.h>
#include <asm/segment.h>
#include <linux/buffer_head.h>
#include <linux/slab.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("ElKing Mina Ashraf");

struct myfile{
	struct file * f;
	mm_segment_t fs;
	loff_t pos;
};

struct myfile * open_file_for_read (char * filename){
	/*printk(KERN_INFO "in the function \n");*/
	struct myfile* mf;
	mf = kmalloc(sizeof(struct myfile), GFP_KERNEL); /*allocating memory for the struct*/

	mf->f = NULL;
	mf->fs = get_fs(); /*the mm_segement of the file*/
    	int error;
	error = 0;

	set_fs(get_ds());
    	mf->f = filp_open(filename, O_RDONLY, 0); /*opening the file in readonly mode*/
   	set_fs(mf->fs);
   	if (IS_ERR(mf->f)) {
		printk(KERN_INFO "Failed to open file!! \n"); /*if file opening failed*/
        	error = PTR_ERR(mf->f); /*save the error number in error */
        	return NULL;
    	}
	/*printk(KERN_INFO "Opened file successfully\n");*/
    return mf; /*return the struct */

}

volatile int read_from_file_until (struct myfile * mf, char * buf, unsigned long vlen, char c){

    int ret;
    set_fs(get_ds());
    char* temp_buf;
    temp_buf = kmalloc(150*sizeof(char), GFP_KERNEL); /*allocate memory for the temp buf*/
	int j;
	for(j=0; j<150; j++)
		temp_buf[j] = 0; /*initialize the bytes to zero or NULL*/

	ret = vfs_read(mf->f, temp_buf, vlen, &(mf->pos)); /*read from the file*/
	int i;
	i = 0;
	int space_counter;
	space_counter = 0;
	int buf_i;
	buf_i = 0;
	printk(KERN_INFO "full file content: %s \n", temp_buf); /*dump full file content*/
	for (i=0; temp_buf[i] != 0; i++){
		if(temp_buf[i] == ' ') {space_counter++; i++;} /*if found a space, add 1 to space counter and move the pointer*/
		if(space_counter == 2){ /*if we are after the second space, start reading into the temp buf until the next space*/
		buf[buf_i] = temp_buf[i];
		buf_i++;
		}
	}
    printk(KERN_INFO "kernel version:%s \n", buf); /*print the kernel version*/
    set_fs(mf->fs);

	return ret;

}

void close_file (struct myfile * mf){

	filp_close(mf->f, NULL); /*close the file*/
}

static int __init init_hello(void)
{
	struct myfile* mf;
	mf = open_file_for_read("/proc/version"); /*pass file path to the function*/
	if(mf == NULL) {printk(KERN_INFO "file pointer is null \n"); close_file(mf);} /*if failed to open file, close it and exit*/
	else {
	char* buffer;
	buffer = (char *) kmalloc(256, GFP_KERNEL); /*allocate the buffer */

	int i;
	for(i=0; i<256; i++)
		buffer[i] = 0; /*calloc it */
	int bytes_read;
	bytes_read = read_from_file_until(mf, buffer, 100, ' '); /*read a max of 100 bytes from the file*/
	close_file(mf);
	kfree(buffer); /*free the memroy*/
	kfree(mf);
}
	return 0;
}

static void __exit cleanup_hello(void)
{
	printk(KERN_INFO "Module removed \n");
}

module_init(init_hello);
module_exit(cleanup_hello);
