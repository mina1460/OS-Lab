#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>
#include <asm/uaccess.h>
#include <linux/seq_file.h>
#include <linux/proc_fs.h>
#include <linux/unistd.h>
#include <linux/slab.h>
#include <linux/fcntl.h>
#include <linux/errno.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("ElKing Mina Ashraf");


#define BUF_LEN 4096
static char cipher_buf[BUF_LEN];

#define KEY_LEN 128
static int major;

static char chrdev_buf[4096];


static char key_buf[KEY_LEN];
static char decryption_key[KEY_LEN];

void rc4(unsigned char * p, unsigned char * k, unsigned char * c, int l)
{
        unsigned char s [256];
        unsigned char t [256];
        unsigned char temp;
        unsigned char kk;
        int i,j,x;
        for ( i  = 0 ; i  < 256 ; i ++ )
        {
                s[i] = i;
                t[i]= k[i % 4];
        }
        j = 0 ;
        for ( i  = 0 ; i  < 256 ; i ++ )
        {
                j = (j+s[i]+t[i])%256;
                temp = s[i];
                s[i] = s[j];
                s[j] = temp;
        }

        i = j = -1;
        for ( x = 0 ; x < l ; x++ )
        {
                i = (i+1) % 256;
                j = (j+s[i]) % 256;
                temp = s[i];
                s[i] = s[j];
                s[j] = temp;
                kk = (s[i]+s[j]) % 256;
                c[x] = p[x] ^ s[kk];
        }
}

static ssize_t key_read(struct file *filp, char __user *buf, size_t count, loff_t *ppos)
{
	int ret; 

 pr_info("Go Away silly! You will not be able to see the Key!\n");
 return 0;
}

static ssize_t key_write(struct file *filp, const char __user *buf, size_t count, loff_t *ppos)
{
	if (count > 128)
	{
		count = 128;
	}
 pr_info("got %ld bytes\n", count);
 copy_from_user(key_buf, buf, count);
 pr_info("key:%s\n", key_buf);

 return count;

}


static int display_cant_read(struct seq_file *m, void *v) {
  seq_printf(m, "Do you really think you can read the key this way?\n");
  return 0;
}
static int key_open(struct inode *inode, struct file *filp)
{
	pr_info("key opened\n");
 return single_open(filp, display_cant_read, NULL);
}

static int key_release(struct inode *inode, struct file *filp)
{
 pr_info("key released\n");
 return 0;
}

static ssize_t cipher_write(struct file *filp, const char __user *buf, size_t count, loff_t *ppos)
{
	memset(cipher_buf, 0, 4096);
	int ret;
 if (*ppos + count >= BUF_LEN)
 count = BUF_LEN - *ppos;
 ret = copy_from_user(chrdev_buf + *ppos, buf, count);
 if (ret < 0)
 return -EFAULT;
 *ppos += count;
chrdev_buf[(*ppos)] = NULL;
	return count;

}

static int display_cipher (struct seq_file *m, void *v) {
	pr_info("fe disp cipher b3d el cipher open\n");
  seq_printf(m, "%s\n", cipher_buf);
  return 0;
}
static int cipher_open(struct inode *inode, struct file *filp)
{
 pr_info("cipher opened\n");
 return single_open(filp, display_cipher, NULL);

}
static int cipher_release(struct inode *inode, struct file *filp)
{
 pr_info("cipher released\n");
 rc4(chrdev_buf, key_buf, cipher_buf, strlen(chrdev_buf));
	pr_info("Cipher: %s\n", cipher_buf);
	pr_info("input: %s\n", chrdev_buf);
/* memset(chrdev_buf, 0, 4096);*/
 return 0;
}

static ssize_t key_proc_write(struct file *filp, const char __user *buf, size_t count, loff_t *ppos)
{

memset(decryption_key, 0, 128);
copy_from_user(decryption_key, buf, count);
pr_info("decryption key: %s", decryption_key);
return count; 
/*int ret;
 if (*ppos + count >= 128)
 count = 128 - *ppos;
 ret = copy_from_user(decryption_key + *ppos, buf, count);
 if (ret < 0)
 return -EFAULT;
 *ppos += count;
decryption_key[(*ppos)+1] = NULL;
pr_info("decryption key: %s", decryption_key);

	return count;*/
}

static struct file_operations cipher_fops = {
 .owner = THIS_MODULE,
 .read = seq_read,
 .write = cipher_write,
 .open = cipher_open,
 .release = cipher_release
};

static struct file_operations key_fops = {
 .owner = THIS_MODULE,
 .read = seq_read,
 .write = key_write,
 .open = key_open,
 .release = key_release
};


static ssize_t prevent_r(struct file *filp, char __user *buf, size_t count, loff_t *ppos)
{
	pr_info("Read operation is not allowed\n");
	return EPERM;
}

static ssize_t prevent_w(struct file *filp,const char __user *buf, size_t count, loff_t *ppos)
{
	pr_info("Write operation is not allowed\n");
	return EPERM;
}


static const struct file_operations Proc_key_fops = {
  .owner = THIS_MODULE,
  /*.read = prevent_r,*/
  .write = key_proc_write,
};

static int dec_disp_cipher(struct seq_file *m, void *v) {
	pr_info("Ready to decrypt\n");
	char* temp;
	temp = kmalloc(4096*sizeof(char), GFP_KERNEL);
	memset(temp,0,4096);
	size_t len = strlen(cipher_buf);
  	rc4(cipher_buf, decryption_key, temp, len);
  	seq_printf(m, "%s\n", temp);
  return 0;
}

static int hello_proc_open(struct inode *inode, struct  file *file) {
	pr_info("about to decrypt and display: \n");
return single_open(file, dec_disp_cipher, NULL);
}


static const struct file_operations Proc_cipher_fops = {
  .owner = THIS_MODULE,
  .open = hello_proc_open,
  .read = seq_read,
 /* .write = prevent_w,
  .llseek = seq_lseek,
  .release = single_release,*/
};


#define N_MINORS 2
struct class *my_class;
struct cdev my_cdev[N_MINORS];
dev_t dev_num;

static int __init chrdev_init(void)
{
	proc_create("cipher",0, NULL, &Proc_cipher_fops);
	proc_create("cipher_key",0, NULL, &Proc_key_fops);
    dev_t curr_dev;
    /* Request the kernel for N_MINOR devices */
    alloc_chrdev_region(&dev_num, 0, N_MINORS, "CIPHER");
        cdev_init(&my_cdev[0], &cipher_fops);
        cdev_init(&my_cdev[1], &key_fops);

        curr_dev = MKDEV(MAJOR(dev_num), MINOR(dev_num));
        cdev_add(&my_cdev[0], curr_dev, 1);
        curr_dev = MKDEV(MAJOR(dev_num), MINOR(dev_num) + 1);
    	cdev_add(&my_cdev[1], curr_dev, 1);
	 return 0;
}

static void __exit chrdev_exit(void)
{
cdev_del(&my_cdev[0]);
cdev_del(&my_cdev[1]);
unregister_chrdev_region(dev_num, 2);
 remove_proc_entry("cipher", NULL);
 remove_proc_entry("cipher_key", NULL);
}

module_init(chrdev_init);
module_exit(chrdev_exit);
