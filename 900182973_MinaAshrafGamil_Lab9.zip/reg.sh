#!/bin/sh
CIPHER_DEVICE="cipher"
CIPHER_KEY_DEVICE="cipher_key"
module="hello"
search="CIPHER"
mode="664"
# invoke insmod with all arguments we got
# and use a pathname, as newer modutils don't look in . by default
/sbin/rmmod $module
/sbin/insmod ./$module.ko || exit 1
# remove stale nodes
rm -f /dev/${CIPHER_DEVICE}
rm -rf /dev/${CIPHER_KEY_DEVICE}

major=$(awk "\$2==\"$search\" {print \$1}" /proc/devices)
echo "major: $major"
mknod /dev/${CIPHER_DEVICE} c $major 0
mknod /dev/${CIPHER_KEY_DEVICE} c $major 1

# give appropriate group/permissions, and change the group.
# Not all distributions have staff, some have "wheel" instead.
group="staff"
grep -q '^staff:' /etc/group || group="wheel"

chgrp $group /dev/${CIPHER_DEVICE}
chgrp $group /dev/${CIPHER_KEY_DEVICE}

chmod $mode /dev/${CIPHER_DEVICE}
chmod $mode /dev/${CIPHER_KEY_DEVICE}

