the makefile works only in the same directory as the code. So place them in the same directory before running make command.

to compile, place the code and the makefile in the same directory and run the "make" command.



you will find an entry in the /proc/ directory called cipher and cipher_key and the same in dev

make sure to run the script reg.sh after you insmod 

make sure it is executable by chmod +x reg.sg 
